using Dominio;

namespace Testes
{

    public class SistemaControleFuncionariosTests
    {
        //TesteCadastroFuncionarioAprovacao:

        //Objetivo: Verificar se o sistema aceita o cadastro de um funcion�rio.
        //Crit�rios de Aceite:
        //O sistema deve permitir o cadastro de um funcion�rio com informa��es v�lidas (matr�cula, sal�rio, cargo, data de admiss�o e data de departamento).
        //Ap�s o cadastro, o sistema deve retornar um resultado positivo indicando sucesso.
        //O funcion�rio cadastrado deve ser �nico, ou seja, n�o pode haver duplicatas com a mesma matr�cula.

        [Theory]
        [InlineData(101, 5000.0, "Analista", "2023-01-01", "2023-01-10")]
        public void TesteCadastroFuncionarioAprovacao(int matricula, double salario, string cargo, string dataAdmissao, string dataDepartamento)
        {
            // Arrange
            var sistema = new Funcionario();

            // Act
            var resultado = sistema.CadastrarFuncionario(matricula, salario, cargo, DateTime.Parse(dataAdmissao), DateTime.Parse(dataDepartamento));

            // Assert
            Assert.True(resultado, "O cadastro do funcion�rio deve ser aprovado.");
        }

        //TesteCadastroProjetoAprovacao:

        //Objetivo: Verificar se o sistema aceita o cadastro de um projeto.
        //Crit�rios de Aceite:
        //O sistema deve permitir o cadastro de um projeto com informa��es v�lidas (ID, nome, descri��o, data de in�cio e ID do departamento).
        //Ap�s o cadastro, o sistema deve retornar um resultado positivo indicando sucesso.
        //O projeto cadastrado deve ser �nico, ou seja, n�o pode haver duplicatas com o mesmo ID.

        [Theory]
        [InlineData(1, "Projeto A", "Descri��o do Projeto A", "2023-02-01", 1)]
        public void TesteCadastroProjetoAprovacao(int id, string nome, string descricao, string dataInicio, int idDepartamento)
        {
            // Arrange
            var sistema = new Funcionario();

            // Act
            var resultado = sistema.CadastrarProjeto(id, nome, descricao, DateTime.Parse(dataInicio), idDepartamento);

            // Assert
            Assert.True(resultado, "O cadastro do projeto deve ser aprovado.");
        }

        //TesteAssociarFuncionarioProjetoAprovacao:

        //Objetivo: Verificar se o sistema aceita a associa��o de um funcion�rio a um projeto.
        //Crit�rios de Aceite:
        //O sistema deve permitir a associa��o de um funcion�rio a um projeto existente.
        //Ap�s a associa��o, o sistema deve retornar um resultado positivo indicando sucesso.
        //A atividade associada deve ser �nica, ou seja, n�o pode haver duplicatas com o mesmo ID de funcion�rio e ID de projeto.

        [Theory]
        [InlineData(101, 1, "Atividade 1", "2023-02-05", "2023-02-10", "2023-02-07", "2023-02-12", 20, 22)]
        public void TesteAssociacaoFuncionarioProjetoAprovacao(int matricula, int idProjeto, string descricao, string dataPrevInit, string dataPrevFin, string dataRealInit, string dataRealFin, double horasPrevistas, double horasFinais)
        {
            // Arrange
            var sistema = new Funcionario();

            // Act
            var resultado = sistema.AssociarFuncionarioProjeto(matricula, idProjeto, descricao, DateTime.Parse(dataPrevInit), DateTime.Parse(dataPrevFin), DateTime.Parse(dataRealInit), DateTime.Parse(dataRealFin), horasPrevistas, horasFinais);

            // Assert
            Assert.True(resultado, "A associa��o de funcion�rio a projeto deve ser aprovada.");
        }

        //TesteAssociarFuncionarioProjetoReprovacao:

        //Objetivo: Verificar se o sistema reprova a associa��o de um funcion�rio a um projeto com datas inv�lidas.
        //Crit�rios de Aceite:
        //O sistema deve retornar um resultado negativo indicando que n�o � poss�vel associar um funcion�rio a um projeto com datas inv�lidas.
        //O sistema deve informar que as datas de in�cio e t�rmino da atividade s�o inconsistentes.

        [Theory]
        [InlineData(102, 2, "Atividade 2", "2023-02-10", "2023-02-15", "2023-02-20", "2023-02-18", 25, 23)]
        public void TesteAssociacaoFuncionarioProjetoReprovacao(int matricula, int idProjeto, string descricao, string dataPrevInit, string dataPrevFin, string dataRealInit, string dataRealFin, double horasPrevistas, double horasFinais)
        {
            // Arrange
            var sistema = new Funcionario();

            // Act
            var resultado = sistema.AssociarFuncionarioProjeto(matricula, idProjeto, descricao, DateTime.Parse(dataPrevInit), DateTime.Parse(dataPrevFin), DateTime.Parse(dataRealInit), DateTime.Parse(dataRealFin), horasPrevistas, horasFinais);

            // Assert
            Assert.False(resultado, "A associa��o de funcion�rio a projeto deve ser reprovada devido �s datas inv�lidas.");
        }

        //TesteAssociarFuncionarioDepartamentoAprovacao:

        //Objetivo: Verificar se o sistema aceita a associa��o de um funcion�rio a um departamento.
        //Crit�rios de Aceite:
        //O sistema deve permitir a associa��o de um funcion�rio a um departamento existente.
        //Ap�s a associa��o, o sistema deve retornar um resultado positivo indicando sucesso.
        //O funcion�rio associado deve existir, e o departamento associado tamb�m deve existir.

        [Theory]
        [InlineData(101, 1)]
        public void TesteAssociarFuncionarioDepartamentoAprovacao(int matricula, int idDepartamento)
        {
            // Arrange
            var sistema = new Funcionario();
            sistema.CadastrarDepartamento(idDepartamento, "TI");

            // Act
            var resultado = sistema.AssociarFuncionarioDepartamento(matricula, idDepartamento);

            // Assert
            Assert.True(resultado, "A associa��o de funcion�rio a departamento deve ser aprovada.");
        }

        //TesteAssociarFuncionarioDepartamentoReprovacao:

        //Objetivo: Verificar se o sistema reprova a associa��o de um funcion�rio a um departamento inexistente.
        //Crit�rios de Aceite:
        //O sistema deve retornar um resultado negativo indicando que n�o � poss�vel associar um funcion�rio a um departamento inexistente.
        //O sistema deve informar que o funcion�rio ou o departamento n�o foi encontrado.

        [Theory]
        [InlineData(102, 2)]
        public void TesteAssociarFuncionarioDepartamentoReprovacao(int matricula, int idDepartamento)
        {
            // Arrange
            var sistema = new Funcionario();

            // Act
            var resultado = sistema.AssociarFuncionarioDepartamento(matricula, idDepartamento);

            // Assert
            Assert.False(resultado, "A associa��o de funcion�rio a departamento deve ser reprovada devido a funcion�rio ou departamento n�o encontrado.");
        }

    }
}