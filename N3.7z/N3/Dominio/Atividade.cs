﻿using System;

namespace Dominio
{
    internal class Atividade
    {
        private int idFuncionario;
        private int idProjeto;
        private string descricao;
        private DateTime dataPrevInit;
        private DateTime dataPrevFin;
        private DateTime dataRealInit;
        private DateTime dataRealFin;
        private double quantidadeHorasPrev;
        private double quantidadeHorasFin;

        public int IdFuncionario { get => idFuncionario; internal set => idFuncionario = value; }
        public int IdProjeto { get => idProjeto; internal set => idProjeto = value; }
        public string Descricao { get => descricao; internal set => descricao = value; }
        public DateTime DataPrevInit { get => dataPrevInit; internal set => dataPrevInit = value; }
        public DateTime DataPrevFin { get => dataPrevFin; internal set => dataPrevFin = value; }
        public DateTime DataRealInit { get => dataRealInit; internal set => dataRealInit = value; }
        public DateTime DataRealFin { get => dataRealFin; internal set => dataRealFin = value; }
        public double QuantidadeHorasPrev { get => quantidadeHorasPrev; internal set => quantidadeHorasPrev = value; }
        public double QuantidadeHorasFin { get => quantidadeHorasFin; internal set => quantidadeHorasFin = value; }
    }
}