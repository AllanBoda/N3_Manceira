﻿using Microsoft.Analytics.Interfaces;
using Microsoft.Analytics.Interfaces.Streaming;
using Microsoft.Analytics.Types.Sql;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Dominio
{
    public class Funcionario
    {
        private DateTime dataDepartamento;
        private DateTime dataAdmissao;
        private string cargo;
        private double salario;
        private int matricula;
        private static List<Funcionario> funcionarios = new List<Funcionario>();
        private static List<Projeto> projetos = new List<Projeto>();
        private static List<Atividade> atividades = new List<Atividade>();
        private static List<Departamento> departamentos = new List<Departamento>();


        public int Matricula { get => matricula; set => matricula = value; }
        public double Salario { get => salario; set => salario = value; }
        public string Cargo { get => cargo; set => cargo = value; }
        public DateTime DataAdmissao { get => dataAdmissao; set => dataAdmissao = value; }
        public DateTime DataDepartamento { get => dataDepartamento; set => dataDepartamento = value; }

        public bool CadastrarFuncionario(int matricula, double salario, string cargo, DateTime dataAdmissao, DateTime dataDepartamento)
        {
            if (funcionarios.Exists(f => f.Matricula == matricula))
            {
                Console.WriteLine("Funcionário já cadastrado.");
                return false;
            }

            var novoFuncionario = new Funcionario
            {
                Matricula = matricula,
                Salario = salario,
                Cargo = cargo,
                DataAdmissao = dataAdmissao,
                DataDepartamento = dataDepartamento
            };

            funcionarios.Add(novoFuncionario);
            Console.WriteLine("Funcionário cadastrado com sucesso.");
            return true;
        }

        public bool CadastrarProjeto(int id, string nome, string descricao, DateTime dataInicio, int idDepartamento)
        {
            if (projetos.Exists(p => p.Id == id))
            {
                Console.WriteLine("Projeto já cadastrado.");
                return false;
            }

            var novoProjeto = new Projeto
            {
                Id = id,
                Nome = nome,
                Descricao = descricao,
                DataInicio = dataInicio,
                IdDepartamento = idDepartamento
            };

            projetos.Add(novoProjeto);
            Console.WriteLine("Projeto cadastrado com sucesso.");
            return true;
        }

        public bool AssociarFuncionarioProjeto(int matricula, int idProjeto, string descricao, DateTime dataPrevInit, DateTime dataPrevFin, DateTime dataRealInit, DateTime dataRealFin, double horasPrevistas, double horasFinais)
        {

            var funcionario = funcionarios.Find(f => f.Matricula == matricula);
            var projeto = projetos.Find(p => p.Id == idProjeto);

            if (funcionario == null || projeto == null)
            {
                Console.WriteLine("Funcionário ou projeto não encontrado.");
                return false;
            }

            if (atividades.Exists(a => a.IdFuncionario == matricula && a.IdProjeto == idProjeto))
            {
                Console.WriteLine("Atividade já cadastrada para este funcionário e projeto.");
                return false;
            }

            var novaAtividade = new Atividade
            {
                Descricao = descricao,
                DataPrevInit = dataPrevInit,
                DataPrevFin = dataPrevFin,
                DataRealInit = dataRealInit,
                DataRealFin = dataRealFin,
                QuantidadeHorasPrev = horasPrevistas,
                QuantidadeHorasFin = horasFinais,
                IdProjeto = idProjeto,
                IdFuncionario = matricula
            };

            atividades.Add(novaAtividade);
            Console.WriteLine("Atividade associada com sucesso.");
            return true;
        }

        
        public bool CadastrarDepartamento(int id, string nome)
        {
            if (departamentos.Exists(d => d.Id == id))
            {
                Console.WriteLine("Departamento já cadastrado.");
                return false;
            }

            var novoDepartamento = new Departamento
            {
                Id = id,
                Nome = nome
            };

            departamentos.Add(novoDepartamento);
            Console.WriteLine("Departamento cadastrado com sucesso.");
            return true;
        }

        public bool AssociarFuncionarioDepartamento(int matricula, int idDepartamento)
        {
            // Verifica se o funcionário e o departamento existem
            var funcionario = funcionarios.Find(f => f.Matricula == matricula);
            var departamento = departamentos.Find(d => d.Id == idDepartamento);

            if (funcionario == null || departamento == null)
            {
                Console.WriteLine("Funcionário ou departamento não encontrado.");
                return false;
            }

            // Associa o funcionário ao departamento
            funcionario.matricula = idDepartamento;
            Console.WriteLine("Funcionário associado ao departamento com sucesso.");
            return true;
        }


    }

}