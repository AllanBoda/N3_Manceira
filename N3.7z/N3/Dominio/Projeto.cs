﻿using System;

namespace Dominio
{
    internal class Projeto
    {
        private int id;
        private string nome;
        private string descricao;
        private DateTime dataInicio;
        private int idDepartamento;

        public int Id { get => id; set => id = value; }
        public string Nome { get => nome; set => nome = value; }
        public string Descricao { get => descricao; set => descricao = value; }
        public DateTime DataInicio { get => dataInicio; set => dataInicio = value; }
        public int IdDepartamento { get => idDepartamento; set => idDepartamento = value; }
    }
}